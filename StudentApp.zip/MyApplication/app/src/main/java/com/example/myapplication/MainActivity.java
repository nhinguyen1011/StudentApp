package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
public class MainActivity extends AppCompatActivity{
   String valToSet ;

    EditText editName;
    EditText editDate;
    TextView editText;
    Button button;
    Button back;
    Spinner spiner;
    String[] mTestArray;
    Button actionButton;
    RadioGroup  radioGroup ;
    RadioButton  radioButton;
    Date date;
    String languages;
    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = findViewById(R.id.editName);
        editDate = findViewById(R.id.editDate);
        spiner = findViewById(R.id.spinner);

        button = findViewById(R.id.button);
        radioGroup = findViewById(R.id.radioGroup);
        // Student student = new Student();
        back = findViewById(R.id.buttonDelete);
        if(Infor.dataSource.size() == 0) {
            back.setVisibility(View.GONE);
        }
        else {
            back.setText("Cancel");
            back.setBackgroundColor(Color.GRAY);
        }
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Languages, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiner.setAdapter(adapter);
        valToSet = spiner.getSelectedItem().toString();


        int radio = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radio);

//        actionButton.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this, ListClass.class);
//                String name =  intent.getStringExtra("name");
//                editText.setText(name);
//                mActivityResultLauncher.launch(intent);
//            }
//        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                String birthday = editDate.getText().toString();
                String classname = valToSet;
                if(TextUtils.isEmpty(name)){
                    showAlert("Please input valid name");
                    return;
                } else if(TextUtils.isEmpty(birthday)) {
                    showAlert("Please input valid birthday");
                    return;
                } else if(TextUtils.isEmpty(classname)) {
                    showAlert("Please input valid classname");
                    return;
                }
                Student student = new Student();
                student.setName(name);
                student.setDate(birthday);
                student.setClassstu(classname);
                student.setGen(radioButton.getText().toString());
                FileUtil.writeData(MainActivity.this,"student.txt", student);
                Infor.newStudent = student;
                setResult(100);
                finish();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Infor.class);
                startActivity(intent);            }
        });
    }

//    ActivityResultLauncher<Intent> mActivityResultLauncher = registerForActivityResult(
//            new ActivityResultContracts.StartActivityForResult(),
//            new ActivityResultCallback<ActivityResult>() {
//                @Override
//                public void onActivityResult(ActivityResult result) {
//                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        // Here, no request code
//                        Intent data = result.getData();
//                        String classname = data.getStringExtra("class");
//                        editText.setText(classname);
//                    }
//                }
//            })

    public void onRadioButtonClicked(View view) {
        radioButton = (RadioButton) view;
        String gender= radioButton.getText().toString();

        Toast.makeText(getApplicationContext(), gender, Toast.LENGTH_SHORT).show();
    }


    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        // Set the message show for the Alert time
        builder.setMessage(message);
        // Set Alert Title
        builder.setTitle("Warning !");
        // Set Cancelable false for when the user clicks on the outside the Dialog Box then it will remain show
        builder.setCancelable(false);
        // Set the positive button with yes name Lambda OnClickListener method is use of DialogInterface interface.
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {
            // When the user click yes button then app will close
            dialog.dismiss();
        });
        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();
    }

}
