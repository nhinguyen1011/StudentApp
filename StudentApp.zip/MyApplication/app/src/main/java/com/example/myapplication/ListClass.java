//package com.example.myapplication;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.ListView;
//import android.widget.Toast;
//
//import androidx.activity.result.ActivityResult;
//import androidx.activity.result.ActivityResultCallback;
//import androidx.activity.result.ActivityResultLauncher;
//import androidx.activity.result.contract.ActivityResultContracts;
//import androidx.appcompat.app.AppCompatActivity;
//
//public class ListClass  extends AppCompatActivity {
//
//    ListView listView;
//    String[] listData;
//    ArrayAdapter<String> adapter;
//    Context context;
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.spinner);
//        context = this;
//        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//        listView = findViewById(R.id.listView);
//        listData = new String[]{
//                "19KTPM1",
//                "19KTPM2",
//                "19KTPM3"
//        };
//        adapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1,listData);
//        listView.setAdapter(adapter);
//
//    listView.setOnItemClickListener(
//         new AdapterView.OnItemClickListener() {
//             @Override
//
//             public void onItemClick(AdapterView<?> parent,
//                                     View view,
//                                     int pos,
//                                     long id) {
//                 String s = listData[pos];
//                 Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
//                 Intent intent = new Intent();
//                 intent.putExtra("class", s);
//                 setResult( Activity.RESULT_OK, intent);
//                 finish();
//             }
//            });
//        }
//
//
//
//
//}
//
