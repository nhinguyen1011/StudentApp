package com.example.myapplication;

import static android.content.Context.MODE_APPEND;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class Student {
    private String name;
    private String date;
    private String classstu;
    private String gen;
    public Student(){

    }
    public Student(String name,String date,String classstu,String gen){
        this.name = name;
        this.date = date;
        this.gen = gen;
        this.classstu = classstu;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClassstu() {
        return classstu;
    }

    public void setClassstu(String classstu) {
        this.classstu = classstu;
    }

    public String getGen() {
        return gen;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public String getInitials() {
        String initials = Arrays.stream(name.split(" "))
                .map(s -> s.substring(0, 1))
                .collect(Collectors.joining());
        return initials;
    }
    @NonNull
    @Override
    public String toString() {
        return name + FileUtil.PATTERN + date +  FileUtil.PATTERN + classstu +  FileUtil.PATTERN + gen;
    }

    public static Student fromString(String data) {
        if(TextUtils.isEmpty(data)) return null;
        String[] arr = data.split(FileUtil.PATTERN);
        Student student = new Student();
        student.setName(arr[0]);
        student.setDate(arr[1]);
        student.setClassstu(arr[2]);
        student.setGen(arr[3]);
        return student;
    }

}
