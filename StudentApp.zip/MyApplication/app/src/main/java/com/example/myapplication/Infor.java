package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.inputmethod.CompletionInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Infor extends AppCompatActivity {
    private enum LayoutManagerType {
        GRID_LAYOUT_MANAGER,
        LINEAR_LAYOUT_MANAGER
    }
    RecyclerView mRecyclerView;
    CustomAdapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    LayoutManagerType mCurrentLayoutManagerType;
    Context context;
    TextView msgTV = null;
    AutoCompleteTextView autoCompleteTV = null;

    ArrayList<String> suggestions =  new ArrayList<>();
    static ArrayList<Student> dataSource = new ArrayList<>();
    static Student seletectStudent = null;
    static Student newStudent = null;

    ImageView btnswitchLayout;
    String strKeyword = "";
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.infor);
        msgTV = findViewById(R.id.tvSuggestion);
        autoCompleteTV = findViewById(R.id.autoCompleteTextView);

        btnswitchLayout = findViewById(R.id.btnswitchLayout);
        btnswitchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCurrentLayoutManagerType == LayoutManagerType.LINEAR_LAYOUT_MANAGER) {
                    mCurrentLayoutManagerType = LayoutManagerType.GRID_LAYOUT_MANAGER;
                }
                else {
                    mCurrentLayoutManagerType = LayoutManagerType.LINEAR_LAYOUT_MANAGER;
                }
                setRecyclerViewLayoutManager(mCurrentLayoutManagerType);
            }
        });
        mRecyclerView= findViewById(R.id.listView);
        mLayoutManager = new LinearLayoutManager(this);
        mCurrentLayoutManagerType = LayoutManagerType.LINEAR_LAYOUT_MANAGER;

        setRecyclerViewLayoutManager(mCurrentLayoutManagerType);
        dataSource = FileUtil.readFileData(Infor.this);

        if(dataSource.size() == 0) {
            startMainActivity();
        }
        mAdapter = new CustomAdapter(dataSource, this);
        mRecyclerView.setAdapter(mAdapter);

        findViewById(R.id.floatingActionButton1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity();
            }
        });

        autoCompleteTV.setThreshold(1);
        updateSuggestionAdapter();


    }

    private void updateSuggestionAdapter() {
        ArrayList<String> items =  new ArrayList<>();
        for(Student item: dataSource) {
            items.add(item.getName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, items);
        suggestions = items;
        autoCompleteTV.setAdapter(adapter);
        autoCompleteTV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                strKeyword = suggestions.get(position);
            }
        });
    }

    private void startMainActivity() {
        Intent intent = new Intent(Infor.this, MainActivity.class);
        mActivityResultLauncher.launch(intent);
    }
    private void updateListView() {
        mAdapter.updateDataSource(dataSource);
        updateSuggestionAdapter();
    }

    public void setRecyclerViewLayoutManager(LayoutManagerType layoutManagerType) {
        int scrollPosition = 0;

        // If a layout manager has already been set, get current scroll position.
        if (mRecyclerView.getLayoutManager() != null) {
            scrollPosition = ((LinearLayoutManager) mRecyclerView.getLayoutManager())
                    .findFirstCompletelyVisibleItemPosition();
        }

        switch (layoutManagerType) {
            case GRID_LAYOUT_MANAGER:
                mLayoutManager = new GridLayoutManager(this, 2);
                mCurrentLayoutManagerType = LayoutManagerType.GRID_LAYOUT_MANAGER;
                btnswitchLayout.setImageDrawable(getDrawable(R.drawable.view_list_24));
                break;
            default:
                mLayoutManager = new LinearLayoutManager(this);
                mCurrentLayoutManagerType = LayoutManagerType.LINEAR_LAYOUT_MANAGER;
                btnswitchLayout.setImageDrawable(getDrawable(R.drawable.grid_view_24));

        }

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.scrollToPosition(scrollPosition);
    }


    ActivityResultLauncher<Intent> mActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode() == 100) {
                        if(newStudent != null) {
                            dataSource.add(newStudent);
                            updateListView();
                        }
                    }
                    else if (result.getResultCode() == Activity.RESULT_OK) {
                        // Here, no request code
                        updateListView();
                        FileUtil.writeListStudentToFile(Infor.this, dataSource);
                    }
                }
            });

    public class CustomAdapter extends RecyclerView.Adapter<ViewHolder> {

        private ArrayList<Student> dataSet;
        Context mContext;

        public CustomAdapter(ArrayList<Student> data, Context context) {
            // super(context, R.layout.list_item_info, data);
            this.dataSet = data;
            this.mContext=context;
        }

        private void updateDataSource(ArrayList<Student> data) {
            dataSet = data;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Create a new view.
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_info, parent, false);

            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student dataModel = dataSet.get(position);
            // Check if an existing view is being reused, otherwise inflate the view

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Object object= dataModel;
                    seletectStudent =(Student) object;
                    // TODO: goto the page edit info
                    Intent intent = new Intent(Infor.this, EditInfo.class);
                    mActivityResultLauncher.launch(intent);
                }
            });

            holder.tvName.setText(dataModel.getName());
            holder.tvClass.setText(dataModel.getClassstu());
            holder.tvInfo.setText(dataModel.getDate() + " - " + dataModel.getGen());
            holder.tvIcon.setText(dataModel.getInitials());
        }

        @Override
        public int getItemCount() {
            if(dataSet != null) {
                return dataSet.size();
            }
            else {
                return 0;
            }
        }
    }

    private static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvName;
        TextView tvClass;
        TextView tvIcon;
        TextView tvInfo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tvName = (TextView) itemView.findViewById(R.id.tvName);
            this.tvIcon = (TextView) itemView.findViewById(R.id.tvIcon);
            this.tvInfo = (TextView) itemView.findViewById(R.id.tvInfo);
            this.tvClass = (TextView) itemView.findViewById(R.id.tvClass);

        }
    }
}

