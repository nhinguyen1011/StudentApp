package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Date;
public class EditInfo extends AppCompatActivity{
    String valToSet;
    EditText editName;
    Spinner spiner;
    EditText editDate;
    TextView editText;
    Button button;
    Button actionButton;
    RadioGroup  radioGroup ;
    RadioButton  radioButton;
    Date date;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = findViewById(R.id.editName);
        editDate = findViewById(R.id.editDate);
        spiner = findViewById(R.id.spinner);
        button = findViewById(R.id.button);
        radioGroup = findViewById(R.id.radioGroup);

        int radio = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radio);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Languages, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiner.setAdapter(adapter);
//        actionButton.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Intent intent = new Intent(EditInfo.this, ListClass.class);
//                String name =  intent.getStringExtra("name");
//                editText.setText(name);
//                mActivityResultLauncher.launch(intent);
//            }
//        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                String birthday = editDate.getText().toString();
                String classname = spiner.getSelectedItem().toString();
                if(TextUtils.isEmpty(name)){
                    showAlert("Please input valid name");
                    return;
                } else if(TextUtils.isEmpty(birthday)) {
                    showAlert("Please input valid birthday");
                    return;
                } else if(TextUtils.isEmpty(classname)) {
                    showAlert("Please input valid classname");
                    return;
                }
                Student student = Infor.seletectStudent;
                student.setName(name);
                student.setDate(birthday);
                student.setClassstu(classname);
                student.setGen(radioButton.getText().toString());

                setResult(Activity.RESULT_OK);
                finish();
            }
        });

        Button btnDelete = findViewById(R.id.buttonDelete);
        btnDelete.setVisibility(View.VISIBLE);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Infor.dataSource.remove(Infor.seletectStudent);
                Infor.seletectStudent = null;
                setResult(Activity.RESULT_OK);
                finish();
            }

        });

        Student student = Infor.seletectStudent;
        editName.setText(student.getName());
        editDate.setText(student.getDate());
        String valSet = student.getClassstu();
        String gen = student.getGen();
        if("Other".equalsIgnoreCase(gen)) {
            radioGroup.check(R.id.radioButton3);
        }
        else if("Female".equalsIgnoreCase(gen)){
            radioGroup.check(R.id.radioButton2);
        }
        else {
            radioGroup.check(R.id.radioButton1);
        }
    }


//    ActivityResultLauncher<Intent> mActivityResultLauncher = registerForActivityResult(
//            new ActivityResultContracts.StartActivityForResult(),
//            new ActivityResultCallback<ActivityResult>() {
//                @Override
//                public void onActivityResult(ActivityResult result) {
//                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        // Here, no request code
//                        Intent data = result.getData();
//                        String classname = data.getStringExtra("class");
//                        editText.setText(classname);
//                    }
//                }
//            });
public void writeData(String filename, Student student) {
    FileOutputStream fos = null;
    try {
        fos = openFileOutput(filename, MODE_APPEND);

        OutputStreamWriter os = new OutputStreamWriter(fos);
        os.write(student.toString());
        os.write("\n");
        os.flush();
    } catch (FileNotFoundException e ) {
        e.printStackTrace();
    } catch (IOException e ) {
        e.printStackTrace();
    }finally {
        if(fos != null){
            try {
                fos.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}


    public void onRadioButtonClicked(View view) {
        radioButton = (RadioButton) view;
        String gender= radioButton.getText().toString();

        Toast.makeText(getApplicationContext(), gender, Toast.LENGTH_SHORT).show();
    }


    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(EditInfo.this);
        // Set the message show for the Alert time
        builder.setMessage(message);
        // Set Alert Title
        builder.setTitle("Warning !");
        // Set Cancelable false for when the user clicks on the outside the Dialog Box then it will remain show
        builder.setCancelable(false);
        // Set the positive button with yes name Lambda OnClickListener method is use of DialogInterface interface.
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) (dialog, which) -> {
            // When the user click yes button then app will close
            dialog.dismiss();
        });
        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();
    }

}
