package com.example.myapplication;

import android.app.Activity;
import android.content.Context;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class FileUtil {
    public static void writeData(Activity context, String filename, Student student) {
        FileOutputStream fos = null;
        try {
            fos = context.openFileOutput(filename, context.MODE_APPEND);

            OutputStreamWriter os = new OutputStreamWriter(fos);
            os.write(student.toString());
            os.write("\n");
            os.flush();
        } catch (FileNotFoundException e ) {
            e.printStackTrace();
        } catch (IOException e ) {
            e.printStackTrace();
        }finally {
            if(fos != null){
                try {
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static String PATTERN = "#,#";

    public static String FILE_NAME = "student.txt";
    public static void writeListStudentToFile(Context context, ArrayList<Student> data) {
        FileOutputStream fos = null;
        try {
            fos = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);

            OutputStreamWriter os = new OutputStreamWriter(fos);
            for(Student student: data) {
                os.write(student.toString());
                os.write("\n");
            }

            os.flush();
        } catch (FileNotFoundException e ) {
            e.printStackTrace();
        } catch (IOException e ) {
            e.printStackTrace();
        }finally {
            if(fos != null){
                try {
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static ArrayList<Student> readFileData(Context context){
        ArrayList<Student> students = new ArrayList<Student>();
        BufferedReader reader;

        try {
            FileInputStream fis = context.openFileInput("student.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            reader = new BufferedReader(isr);
            String line = reader.readLine();

            while (line != null) {
                System.out.println(line);
                // read next line
                Student item = Student.fromString(line);
                if(item != null) {
                    students.add(item);
                }
                line = reader.readLine();
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return students;
    }
}
